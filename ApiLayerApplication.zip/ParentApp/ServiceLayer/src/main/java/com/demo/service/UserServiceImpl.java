package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.User;
import com.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;
	
	@Override
	public User saveUser(User user) {
		
		User newuser = new User();
		newuser.setName(user.getName());
		newuser.setEmail(user.getEmail());
		newuser.setAge(user.getAge());
		User user1 = userRepo.save(newuser);
		
		return user1;
	}

}
